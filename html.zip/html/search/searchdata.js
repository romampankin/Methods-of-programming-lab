var indexSectionsWithContent =
{
  0: "_adefhimnprsuxy",
  1: "r",
  2: "m",
  3: "m",
  4: "_his",
  5: "adefhinprsuxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Пространства имен",
  3: "Файлы",
  4: "Функции",
  5: "Переменные"
};

