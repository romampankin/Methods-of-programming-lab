var searchData=
[
  ['insert_5fsort_0',['insert_sort',['../namespace_m_p___lab1.html#a1b56e74893af161582f55913fc1b9568',1,'MP_Lab1']]],
  ['insert_5ftime_1',['insert_time',['../namespace_m_p___lab1.html#a8ce57d6d94683a8dd6017701e5fe95d0',1,'MP_Lab1']]]
];
