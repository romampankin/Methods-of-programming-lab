var searchData=
[
  ['insert_5fsort_0',['insert_sort',['../namespace_m_p___lab1.html#a1b56e74893af161582f55913fc1b9568',1,'MP_Lab1']]]
];
