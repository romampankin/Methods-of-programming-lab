var searchData=
[
  ['heap_5ftime_0',['heap_time',['../namespace_m_p___lab1.html#a1b2f8ecb659dfd238b941bd61a9b0c9a',1,'MP_Lab1']]],
  ['house_1',['house',['../class_m_p___lab1_1_1residents.html#a7e84e96b69d328b2a7480cb31f034c50',1,'MP_Lab1::residents']]]
];
